__version__ = "1.0.1"
# 项目支持的模型
SUPPORT_MODEL = ['ERes2Net', 'CAMPPlus', 'EcapaTdnn', 'Res2Net', 'ResNetSE', 'TDNN']
